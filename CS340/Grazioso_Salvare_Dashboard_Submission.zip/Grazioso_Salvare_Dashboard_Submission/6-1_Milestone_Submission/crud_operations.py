from pymongo import MongoClient

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        """
        Initialize the connection to MongoDB with user authentication.
        :param username: The MongoDB username.
        :param password: The MongoDB password.
        """
        HOST = 'nv-desktop-services.apporto.com'  # MongoDB host
        PORT = 33257  # MongoDB port
        DB = 'AAC'  # Database name
        COL = 'animals'  # Collection name

        # Create the connection string
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]
        print(f"Connected to MongoDB database '{DB}', collection '{COL}'.")

    def create(self, data):
        """
        Insert a document into the MongoDB collection.
        :param data: A dictionary containing the document to be inserted.
        :return: True if the operation is successful, otherwise False.
        """
        print(f"Attempting to create a new document: {data}")  # Debugging
        if data is not None:  # Ensure data is provided
            try:
                self.collection.insert_one(data)  # Insert the document
                print("Document successfully inserted.")
                return True
            except Exception as e:
                print(f"Error while inserting data: {e}")
                return False
        else:
            raise ValueError("Data parameter cannot be None")

    def read(self, query):
        """
        Query documents from the MongoDB collection.
        :param query: A dictionary containing the query parameters.
        :return: A list of documents matching the query.
        """
        print(f"Executing read query: {query}")  # Debugging
        if query is not None:  # Ensure a query is provided
            try:
                results = self.collection.find(query)  # Query the collection
                results_list = [doc for doc in results]  # Convert the results to a list
                print(f"Read query returned {len(results_list)} document(s).")
                return results_list
            except Exception as e:
                print(f"Error while querying data: {e}")
                return []
        else:
            raise ValueError("Query parameter cannot be None")

    def update(self, query, new_values):
        """
        Update document(s) in the MongoDB collection.
        :param query: A dictionary specifying which documents to update.
        :param new_values: A dictionary specifying the new field values.
        :return: The number of documents updated.
        """
        print(f"Executing update query: {query} with values: {new_values}")  # Debugging
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                print(f"{result.modified_count} document(s) updated.")
                return result.modified_count  # Number of documents modified
            except Exception as e:
                print(f"Error while updating data: {e}")
                return 0
        else:
            raise ValueError("Query and new_values parameters cannot be None")

    def delete(self, query):
        """
        Delete document(s) from the MongoDB collection.
        :param query: A dictionary specifying which documents to delete.
        :return: The number of documents deleted.
        """
        print(f"Executing delete query: {query}")  # Debugging
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                print(f"{result.deleted_count} document(s) deleted.")
                return result.deleted_count  # Number of documents deleted
            except Exception as e:
                print(f"Error while deleting data: {e}")
                return 0
        else:
            raise ValueError("Query parameter cannot be None")

    # Filtering methods for dashboard
    def get_water_rescue_dogs(self):
        """
        Retrieve dogs suitable for Water Rescue.
        """
        query = {
            "$and": [
                {"breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]}},
                {"sex_upon_outcome": "Intact Female"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        print(f"Executing query for Water Rescue Dogs: {query}")  # Debugging
        return self.read(query)

    def get_mountain_rescue_dogs(self):
        """
        Retrieve dogs suitable for Mountain or Wilderness Rescue.
        """
        query = {
            "$and": [
                {"breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        print(f"Executing query for Mountain Rescue Dogs: {query}")  # Debugging
        return self.read(query)

    def get_disaster_rescue_dogs(self):
        """
        Retrieve dogs suitable for Disaster or Individual Tracking.
        """
        query = {
            "$and": [
                {"breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}}
            ]
        }
        print(f"Executing query for Disaster Rescue Dogs: {query}")  # Debugging
        return self.read(query)